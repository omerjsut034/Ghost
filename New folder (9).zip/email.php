<?php
$emailku = 'omer4adel0@gmail.com'; // GANTI EMAIL KAMU DISINI
?>